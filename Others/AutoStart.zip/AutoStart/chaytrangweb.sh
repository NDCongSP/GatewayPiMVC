sleep 10s;
epiphany-browser http://localhost/Data